package tripexporter;

/**
 * 
 * @author Christian V. (aka MrChrHD/StoKatze/Bunny/King Bunny I)
 * @version  2.0 05/11/2018
 * @since Java 8
 * 
 **/
public class GUI
{

	/**
	 * Main. Creates a window.
	 * @param args CLI Commands -- Not used
	 */
	public static void main (String args[])
	{
		/**
		 * Main window
		 */
		Window window = new Window();
	}
}
